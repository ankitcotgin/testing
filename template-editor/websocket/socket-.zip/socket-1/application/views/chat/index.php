<!DOCTYPE html>
<html lang="en">

<head>
    <title>Chat</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <form method="post" id="sendMessageForm">
                <div class="mb-3 mt-3">
                    <input type="text" class="form-control" id="receiverId" name="receiverId" placeholder="Enter receiver user id" value="2">
                </div>
                <div class="mb-3">
                    <textarea class="form-control" id="message" name="message" placeholder="Enter Message" rows="3">Hello Artisan</textarea>
                </div>
                <button type="button" name="sendmessage" class="btn btn-primary sendmessage">Send</button>
            </form>
            <div class="mb-3 mt-3 text-danger" id="messagechat"></div>
        </div>
    </div>

    <script>
        // Use JavaScript to send messages via WebSocket
        var conn = new WebSocket('ws://localhost:8080');

        conn.onopen = function(e) {
            console.log("Connection established!");
        };

        // conn.onmessage = function(e) {
        //     var messagechat = document.getElementById('messagechat');
        //     messagechat.innerHTML += '<p>' + e.data + '</p>';
        // };

        conn.onmessage = function(e) {
        var data = JSON.parse(e.data);
        var showmessage = document.getElementById('messagechat');

            // Update showmessage div with the received message
            showmessage.innerHTML += '<div class="row"><div class="col-6">' + data.sender + '</div><div class="col-6">' + data.message + '</div></div>';
        };

        $('.sendmessage').on('click', function() {
            var receiverId = $('#receiverId').val();
            var message = $('#message').val();
            var data = {
                receiverId: receiverId,
                message: message
            };
            conn.send(JSON.stringify(data));
            $.ajax({
                type: 'POST',
                url: '<?= base_url('chat/sendMessage') ?>',
                data: data,
                dataType: 'json',
                success: function(response) {
                    // Handle the response if needed
                }
            });
        });
    </script>
</body>

</html>